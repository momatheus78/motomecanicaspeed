#!/usr/bin/env python3
"""
Studio Viral — Servidor Local
Rode este arquivo e acesse: http://localhost:8080
"""

import http.server
import urllib.request
import urllib.error
import json
import os
import sys

PORT = 8080
OLLAMA = "http://localhost:11434"

class Handler(http.server.BaseHTTPRequestHandler):

    def log_message(self, format, *args):
        pass  # silencia logs desnecessários

    def send_cors(self):
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")

    def do_OPTIONS(self):
        self.send_response(200)
        self.send_cors()
        self.end_headers()

    def do_GET(self):
        # Servir o index.html
        if self.path == "/" or self.path == "/index.html":
            try:
                caminho = os.path.join(os.path.dirname(__file__), "index.html")
                with open(caminho, "rb") as f:
                    conteudo = f.read()
                self.send_response(200)
                self.send_header("Content-Type", "text/html; charset=utf-8")
                self.send_cors()
                self.end_headers()
                self.wfile.write(conteudo)
            except FileNotFoundError:
                self.send_response(404)
                self.end_headers()
                self.wfile.write(b"index.html nao encontrado na mesma pasta")
            return

        # Proxy para /api/tags (verificar modelos)
        if self.path == "/ollama/tags":
            try:
                req = urllib.request.urlopen(f"{OLLAMA}/api/tags", timeout=5)
                dados = req.read()
                self.send_response(200)
                self.send_header("Content-Type", "application/json")
                self.send_cors()
                self.end_headers()
                self.wfile.write(dados)
            except Exception as e:
                self.send_response(502)
                self.send_cors()
                self.end_headers()
                self.wfile.write(json.dumps({"error": str(e)}).encode())
            return

        self.send_response(404)
        self.end_headers()

    def do_POST(self):
        # Proxy para /api/generate
        if self.path == "/ollama/generate":
            tamanho = int(self.headers.get("Content-Length", 0))
            corpo = self.rfile.read(tamanho)

            # Garante stream: false no body
            try:
                body_json = json.loads(corpo)
                body_json["stream"] = False
                corpo = json.dumps(body_json).encode()
            except Exception:
                pass

            try:
                req = urllib.request.Request(
                    f"{OLLAMA}/api/generate",
                    data=corpo,
                    headers={"Content-Type": "application/json"},
                    method="POST"
                )
                # Timeout de 5 minutos — suficiente para qualquer modelo
                resp = urllib.request.urlopen(req, timeout=300)
                dados = resp.read()
                self.send_response(200)
                self.send_header("Content-Type", "application/json")
                self.send_cors()
                self.end_headers()
                self.wfile.write(dados)
            except urllib.error.URLError as e:
                self.send_response(502)
                self.send_header("Content-Type", "application/json")
                self.send_cors()
                self.end_headers()
                self.wfile.write(json.dumps({"error": f"Ollama nao respondeu: {str(e)}"}).encode())
            except Exception as e:
                self.send_response(500)
                self.send_header("Content-Type", "application/json")
                self.send_cors()
                self.end_headers()
                self.wfile.write(json.dumps({"error": str(e)}).encode())
            return

        self.send_response(404)
        self.end_headers()


def main():
    print("=" * 50)
    print("  🎬 Studio Viral — Servidor Local")
    print("=" * 50)
    print(f"\n  ✅ Servidor rodando em: http://localhost:{PORT}")
    print(f"  🤖 Conectando ao Ollama em: {OLLAMA}")
    print("\n  👉 Abra no navegador: http://localhost:8080")
    print("\n  Para parar: pressione CTRL+C")
    print("=" * 50)

    try:
        server = http.server.HTTPServer(("localhost", PORT), Handler)
        server.serve_forever()
    except KeyboardInterrupt:
        print("\n\n  Servidor encerrado. Até logo!")
        sys.exit(0)
    except OSError as e:
        if "Address already in use" in str(e) or "10048" in str(e):
            print(f"\n  ❌ Porta {PORT} já está em uso.")
            print(f"  Tente fechar outros programas ou reinicie o PC.")
        else:
            print(f"\n  ❌ Erro: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main()
